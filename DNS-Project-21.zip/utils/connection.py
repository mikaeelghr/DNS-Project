class Connection:
    authorized = None
    username = None


